var AWS = require("aws-sdk");
var https = require('https');
var mysql = require('mysql');
// var nodemailer = require('nodemailer')
var ses = new AWS.SES({region: 'ap-south-1'});
var connection;

exports.handler = (event, context, callback) => {
            
                            if(!event.hasOwnProperty("ahu_checker")){
                                callback("Valid parameter not found");
                                return;
                            }
                            
                            const nowMilliSecs = Date.now();
                            console.log('Current timestamp:', nowMilliSecs);
                            //console.log('check1')
                            var latestentrytime=''
                            var emailerrormsg = ''
                            let emailerrorlist = [];
                            var teleerrormsg = ''
                            let teleerrorlist = [];
                            //var errmsg =''
                            var subject = 'Problem Detected with AHU data:'
                            
                            var emailIDArr = [
                                    "ruturajraut2000@gmail.com",
                                    "gautam@claypot.in",
                                    //"chauhan@claypot.in",
                                    //"tech-assist@claypot.in",
                                    //"yogesh@claypot.in"
                                    
                                ];
                        
                            const connection = mysql.createConnection({
                                host: "claypot-db-instance.ci3ywfy1btrn.ap-south-1.rds.amazonaws.com",
                                user: "claypot_db_user",
                                password: "claypot_db_user_password",
                                database: "claypot_db",
                                multipleStatements: true
                            })
                        
                            
                            
                            connection.connect(err => {
                                console.log('in funct')
                                if (err) {
                                    console.error('Error conecting to my sql', err)
                                    return;
                                }
                                //console.log('connection established')
                            });
                            
                            let now = new Date();
                            now.setTime(now.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
                            
                            //console.log(now);
                            
                            
                             // Define the start and end time of the time window (8:30 am to 6:30 pm) /---
                            var startTime = new Date(now);
                            startTime.setHours(8, 30, 0, 0); // Set to 8:30 am
                            var endTime = new Date(now);
                            endTime.setHours(12, 30, 0, 0); // Set to 6:30 pm  18:30
                            
                            let year = now.getFullYear();
                            let month = now.getMonth() + 1;
                            let day = now.getDate();
                            let hour = now.getHours();
                            
                            if(month < 10){month = "0" + month};
                            if(day < 10){day = "0" + day};
                            if(hour < 10){hour = "0" + hour};
                            
                            
                            
                            const dateTimeString = year + "-" + month + "-" + day + " " + hour;
                            const dateString = year + "-" + month + "-" + day;
                            
                            
                            //console.log("Date time string:",dateTimeString);
                            
                            
                            
                        var query = `SELECT * FROM claypot_db.quantum_ahu WHERE ahu_id = 'solusAhu1' and  dt LIKE  '${dateTimeString}%';`;
                        query += `SELECT * FROM claypot_db.quantum_ahu WHERE ahu_id = 'solusAhu2' and dt LIKE  '${dateTimeString}%';`;
                        query += `SELECT * FROM claypot_db.quantum_ahu WHERE ahu_id = 'bayerAhu1' and  dt LIKE  '${dateTimeString}%';`;
                        query += `SELECT * FROM claypot_db.quantum_ahu WHERE ahu_id = 'bayerAhu2' and  dt LIKE  '${dateTimeString}%';`;
                        
                        // query += `select ahu_name,run_status,dt from claypot_db.quantum_ahu where ahu_id= 'solusAhu1' order by id desc limit 1;`;
                        //  query += `select ahu_name,run_status,dt from claypot_db.quantum_ahu where ahu_id= 'solusAhu2' order by id desc limit 1;`;
                        // query += `select ahu_name,run_status,dt from claypot_db.quantum_ahu where ahu_id= 'bayerAhu1' order by id desc limit 1;`;
                        // query += `select ahu_name,run_status,dt from claypot_db.quantum_ahu where ahu_id= 'bayerAhu2' order by id desc limit 1;`;
                        
                        //console.log(query)
                
                        
                            //console.log('incallback')
                            connection.query(query, (err, result) => {
                                if (err) {
                                    console.error('Error executing query', err)
                                    return;
                                } else {
                                    
                                    //console.log("result---->",result)
                                   
                                    // Process only the results of the first four queries
                                //Assuming result is your array of query results
                                //Process only the results of the first four queries
                                for (let i = 0; i < 4; i++) {
                                    let ahuName = ['solusAhu1', 'solusAhu2', 'bayerAhu1', 'bayerAhu2'][i];
                                    
                                    // Access the query result for the current query (index i)
                                    const queryResult = result[i];
                                    
                                    //console.log("Query Result +======",queryResult)
                                    
                                        
                                    //console.log("queryResult Length", queryResult.length)
                                
                                    // Send alert to mail and telegram for each condition
                                    if (queryResult.length === 0) {
                                        
                                        const emailerrormsg = `<br> Octopus has detected that the latest data of ${ahuName} has not been uploaded.</b><br>`;
                                        console.error(emailerrormsg);
                                        emailerrorlist.push(emailerrormsg);
                                
                                        const teleerrormsg = `\n Octopus has detected that the latest data of ${ahuName} has not been uploaded.\n\n`;
                                        console.error(teleerrormsg);
                                        teleerrorlist.push(teleerrormsg);
                                        
                                        continue;
                                    } 
                                    
                                    const row = queryResult[0]
                                    const recordDt = row.dt;
                                    
                                    
                                    const recDt = new Date(recordDt);
                                    console.log("Record Dt :", recDt)
                                    
                                    console.log("Start Time",startTime)
                                    console.log("End Time",endTime)
                                    
                                    console.log(recDt > startTime);
                                    
                                    
                                    if((recDt > startTime && recDt < endTime) && queryResult[0].run_status == 0){
                                        
                                        emailerrorlist.push(`<br> Octopus has detected that ${ahuName} is OFF when it is supposed to be ON (between 8:30 AM and 6:30 PM)</b><br>`);
                                        teleerrorlist.push(`\n Octopus has detected that ${ahuName} is OFF when it is supposed to be ON (between 8:30 AM and 6:30 PM)\n\n`);
                                    }
                                    
                                    if((recDt < startTime || recDt > endTime) && queryResult[0].run_status == 1){
                                        
                                        emailerrorlist.push(`<br> Octopus has detected that ${ahuName} is ON when it is supposed to be OFF (before 8:30 AM and after 6:30 PM)</b><br>`);
                                        teleerrorlist.push(`\n Octopus has detected that ${ahuName} is ON when it is supposed to be OFF (before 8:30 AM and after 6:30 PM)\n\n`);
                                    }
                                    
                            
                                }
                                
                                console.log("Email Error List ==>",emailerrorlist)
                                if(emailerrorlist.length > 0){
                                    
                                    sendMail(emailIDArr,subject,emailerrorlist,callback)
                                
                                }  
                                else{
                                    console.log("Error in mail sending")
                                    
                                }
                                console.log("Telegram Error List ==>",teleerrorlist)
                                if(teleerrorlist.length > 0){
                                    sendPhotoToTelegram(teleerrorlist,callback)
                                
                                }  
                                else{
                                    noErrorMsgToTelegram(callback); // add callback if deleted
                                    
                                }
                                
                                     
                                connection.end()

                            }

            })
        }
  

async function sendPhotoToTelegram(teleerrorlist,callback) {
    // Construct the URL for the Telegram Bot API endpoint
    console.log('in telegram function')
    var photoUrl = `https://www.octopus-automation.com/apps/eqi/images/telegram/air-quality-problem.png`;
    var URLString = 'https://api.telegram.org/bot5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU/sendPhoto';

    URLString +=`?chat_id=-1001640441317`; // test channel
    URLString += `&photo=${photoUrl}`;
   
    var teleerrorMessage = `Problem Detected with AHU are as follows:\n\n${teleerrorlist.map(error => `-${error}`).join('\n\n')}`;
    var telecontent =  teleerrorMessage.split('<br>').join('')
    
   // console.log("Error msg ----+",teleerrorMessage)
    
    console.log('********',telecontent)
    // Append the error message to the URL string
    URLString += `&caption=${encodeURIComponent(telecontent)}`;
    URLString += `&parse_mode=html`;
    //console.log("URLString", URLString)

  
      // Make the HTTP request to send the photo
          // Make the HTTP request to send the photo
    const request = new https.get(URLString, (response) => {
        //console.log('in response');
        console.log('Telegram API response:', response.statusCode);
        callback(null,`Telegram response code ${response.statusCode}`);
       
    }).on('error', (error) => {
        console.error('Telegram API call Error:', error.message);   // error.message
        callback(error.message);   // same
        
    });
    
    //request.end();

    
}

async function noErrorMsgToTelegram(callback) {
    // Construct the URL for the Telegram Bot API endpoint
    //console.log('in telegram function');
    var photoUrl = `https://www.octopus-automation.com/apps/eqi/images/telegram/air-quality-problem.png`;
    var URLString = 'https://api.telegram.org/bot5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU/sendPhoto';

    URLString += `?chat_id=-1001640441317`; // test channel
    URLString += `&photo=${photoUrl}`;
    var telecontent =  `<b>AHU data Checked.</b>\n\n`;
    telecontent += `No change Detected `;
    console.log('********',telecontent);
    
    // Append the error message to the URL string
    URLString += `&caption=${encodeURIComponent(telecontent)}`;
    URLString += `&parse_mode=html`;

  
    // Make the HTTP request to send the photo
    const request = new https.get(URLString, (response) => {
        //console.log('in response')
        console.log('Telegram API response:', response.statusCode);
        callback(null,`Telegram response code ${response.statusCode}`)
    }).on('error', (error) => {
        console.error('Telegram API call Error:', error.message);
        callback(error.message)
    });
    
}

async function mailcontent(errorlist,ahuName) {
    let mailContent = `<html>`;
    mailContent += `<body>`;
    mailContent += `<h2 style="color:darkgreen">AHU  data </h2>`;
    mailContent += `<table id="octopus-table" border=1 bordercolor="#fff" cellspacing=0 cellpadding=15 style="border-radius:15px">`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th colspan=3>AHU Alert</th>`;
    mailContent += `</tr>`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th style="text-align:center;background-color:green;color:#fff">Problem Detected with AHU</th>`;
    mailContent += `</tr>`;

    // Append dynamic table rows based on errorlist
    errorlist.forEach(error => {
        mailContent += `<tr>`;
        mailContent += `<td style="background-color:orange;color:#fff"><b>${error}</b></td>`;
        mailContent += `</tr>`;
    });


    // Close HTML body and table tags
    mailContent += `</table>`;
    mailContent += `</body>`;
    mailContent += `</html>`;

    return mailContent;
}


async function sendMail(emailIdArr,subject,errorlist,callback)
    {
        console.log(emailIdArr);
        // console.log(data);
        var msg = await mailcontent(errorlist); // Call mailcontent function here to get the mail message
        //console.log("---msg---",msg);
        const emailParams = {
           
            Destination: {
              //ToAddresses: ["gautam@claypot.in","yogesh@claypot.in"],
              ToAddresses: emailIdArr,
            },
            Message: {
              Body: {
                Html: { Data: msg },
              },
              Subject: { Data: subject },
            },
            Source: "octopus-alerts@octopusio.io",
        };
        console.log('after mail content');
          
        try {
            let key = await ses.sendEmail(emailParams).promise();
            console.log("MAIL SENT SUCCESSFULLY!!");
            callback(null,true);
        } catch (e) {
            //console.log("FAILURE IN SENDING MAIL!!", e);
            callback("Failure in sending mail" + e);
          }  
        return;
}